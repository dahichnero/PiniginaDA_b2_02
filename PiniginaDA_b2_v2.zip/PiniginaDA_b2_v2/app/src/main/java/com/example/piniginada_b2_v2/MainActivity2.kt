package com.example.piniginada_b2_v2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner

class MainActivity2 : AppCompatActivity() {
    lateinit var chfigure: Spinner
    lateinit var chres: Spinner
    lateinit var valueMy: EditText
    lateinit var count: Button
    lateinit var valueMytwo: EditText

    val numbers: Array<Long> = arrayOf(1,1000, 1000000,1000000000)
    val res:Long=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        chfigure=findViewById(R.id._dynamic)
        chres=findViewById(R.id._dynamictwo)
        valueMy=findViewById(R.id.editText3)
        count=findViewById(R.id.suumma)
        valueMytwo=findViewById(R.id.editText4)
        valueMytwo.isEnabled=false
        val adapter: ArrayAdapter<*> =ArrayAdapter.createFromResource(
            this, R.array.bitesNames, android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        chfigure.adapter=adapter
        chres.adapter=adapter
        chfigure.onItemSelectedListener=object:
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {

            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

        }
        chres.onItemSelectedListener=object:
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

        }
        count.setOnClickListener {
            val intent=Intent(this,MainActivity3::class.java)
            intent.putExtra("result",res)
            startActivity(intent)
        }
    }
}
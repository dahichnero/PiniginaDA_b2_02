package com.example.piniginada_b2_v2

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    lateinit var login: EditText
    lateinit var password: EditText
    lateinit var shared: SharedPreferences
    lateinit var regs: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        login=findViewById(R.id.editText)
        password=findViewById(R.id.editText2)
        shared=getSharedPreferences("ACCOUNT", MODE_PRIVATE)
        regs=findViewById(R.id.start)
        regs.setOnClickListener {
            if (!shared.contains("LOGIN") && !shared.contains("PASSWORD")){
                if (login.text.toString().isNotEmpty() && password.text.toString().isNotEmpty()){
                    var editing=shared.edit()
                    editing.putString("LOGIN",login.text.toString())
                    editing.putString("PASSWORD",password.text.toString())
                    editing.apply()
                    val intent=Intent(this,MainActivity2::class.java)
                    startActivity(intent)
                }
                else{
                    val alert=AlertDialog.Builder(this).setTitle("Error").setMessage("Is empty...").setPositiveButton("Ok",null).create().show()
                }
            }
            else{
                var log=shared.getString("LOGIN","NONE")
                var pass=shared.getString("PASSWORD","NONE")
                if (login.text.toString()==log && password.text.toString()==pass){
                    val intent= Intent(this,MainActivity2::class.java)
                    startActivity(intent)
                }
                else{
                    val alert=
                        AlertDialog.Builder(this).setTitle("Error").setMessage("Wrong data...").setPositiveButton("Ok",null).create().show()
                }
            }
        }
    }
}